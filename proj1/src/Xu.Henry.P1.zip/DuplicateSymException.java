/**
 * DuplicateSymException
 *
 * Exception for adding duplicate Sym to a scope.
 *
 *  @author Henry Xu
 */
public class DuplicateSymException extends Exception {
}
